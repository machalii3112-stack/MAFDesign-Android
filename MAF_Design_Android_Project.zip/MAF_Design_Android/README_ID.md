# MAF Design Android (proyek APK)

Proyek Android native dengan WebView yang memuat aplikasi MAF Design secara lokal dari `app/src/main/assets/index.html`.

## Fitur
- Data pesanan dan harga tersimpan lokal di WebView localStorage pada HP.
- Daftar harga dan produk tambahan.
- Nota dan cetak/simpan PDF melalui layanan cetak Android.
- Bagikan nota melalui WhatsApp (tautan eksternal dibuka dengan aplikasi yang tersedia).
- Riwayat, status pesanan, DP, sisa pembayaran, laporan omzet/laba.
- Backup JSON melalui pemilih lokasi Android; restore memilih file JSON dari penyimpanan.

## Cara membangun APK
1. Instal **Android Studio** di komputer (Windows/macOS/Linux) dan Android SDK Platform 35, serta JDK 17.
2. Ekstrak ZIP ini ke folder di komputer.
3. Buka Android Studio → **Open** → pilih folder `MAF_Design_Android` hasil ekstrak.
4. Jika diminta, izinkan Android Studio menyiapkan Gradle wrapper dan lakukan **Sync Project with Gradle Files**. Pastikan koneksi internet tersedia untuk mengunduh plugin Gradle/SDK yang diperlukan.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android, buka file tersebut, lalu izinkan **Install unknown apps** bila diminta.

## Catatan penting
- ZIP ini adalah proyek sumber Android yang siap dibuka dan dibangun di Android Studio, **bukan file APK yang sudah dikompilasi**.
- Data lokal berada pada penyimpanan aplikasi di HP tersebut. Uninstall aplikasi atau menghapus data aplikasi dapat menghapus data lokal. Lakukan backup JSON secara berkala.
- File backup dapat disimpan ke folder pilihan melalui pemilih dokumen Android. Restore hanya menerima file backup JSON yang strukturnya sesuai.
