MAF DESIGN ANDROID - PROJECT SUMBER APK

Isi folder ini adalah proyek Android Studio untuk membangun aplikasi APK MAF Design.
Aplikasi membuka index.html dari aset lokal Android (tidak memerlukan hosting/internet untuk fungsi lokal).
Data pesanan/harga disimpan di penyimpanan WebView (localStorage) pada perangkat.

PENTING:
- Ini proyek sumber, BUKAN file APK yang sudah terkompilasi.
- Untuk menghasilkan APK, buka folder ini dengan Android Studio pada komputer yang memiliki Android SDK.
- Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
- File APK biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
- Fitur berbagi WhatsApp memerlukan internet dan aplikasi WhatsApp.
- Simpan backup data secara berkala; menghapus data aplikasi dapat menghapus riwayat.
